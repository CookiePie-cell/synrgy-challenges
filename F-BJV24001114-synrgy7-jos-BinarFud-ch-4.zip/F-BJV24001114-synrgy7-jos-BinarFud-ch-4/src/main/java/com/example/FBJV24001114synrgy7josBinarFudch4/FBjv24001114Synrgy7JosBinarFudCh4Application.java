package com.example.FBJV24001114synrgy7josBinarFudch4;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FBjv24001114Synrgy7JosBinarFudCh4Application {

	public static void main(String[] args) {
		SpringApplication.run(FBjv24001114Synrgy7JosBinarFudCh4Application.class, args);
	}

}
