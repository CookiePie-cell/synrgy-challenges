# Read Me First
The following was discovered as part of building this project:

* The original package name 'com.example.F-BJV24001114-synrgy7-jos-BinarFud-ch-4' is invalid and this project uses 'com.example.FBJV24001114synrgy7josBinarFudch5' instead.

# Getting Started

### Reference Documentation
For further reference, please consider the following sections:

* [Official Apache Maven documentation](https://maven.apache.org/guides/index.html)
* [Spring Boot Maven Plugin Reference Guide](https://docs.spring.io/spring-boot/docs/3.2.5/maven-plugin/reference/html/)
* [Create an OCI image](https://docs.spring.io/spring-boot/docs/3.2.5/maven-plugin/reference/html/#build-image)

