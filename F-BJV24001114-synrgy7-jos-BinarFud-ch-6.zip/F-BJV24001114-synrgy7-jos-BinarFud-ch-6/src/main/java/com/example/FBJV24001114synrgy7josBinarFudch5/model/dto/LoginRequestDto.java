package com.example.FBJV24001114synrgy7josBinarFudch5.model.dto;

import lombok.Data;

@Data
public class LoginRequestDto {
    private String username;
    private String password;
}
