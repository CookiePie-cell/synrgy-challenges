package com.example.FBJV24001114synrgy7josBinarFudch5.service;

import java.util.UUID;

public interface InvoiceService {
    byte[] generateInvoice(UUID userId);
}
