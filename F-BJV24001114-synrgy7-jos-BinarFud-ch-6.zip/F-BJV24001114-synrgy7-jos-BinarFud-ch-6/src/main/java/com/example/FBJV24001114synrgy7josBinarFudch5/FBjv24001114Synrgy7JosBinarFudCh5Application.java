package com.example.FBJV24001114synrgy7josBinarFudch5;

import io.swagger.v3.oas.annotations.OpenAPIDefinition;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FBjv24001114Synrgy7JosBinarFudCh5Application {

	public static void main(String[] args) {
		SpringApplication.run(FBjv24001114Synrgy7JosBinarFudCh5Application.class, args);
	}

}
