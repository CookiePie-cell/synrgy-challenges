package com.example.FBJV24001114synrgy7josBinarFudch5.model.dto;

import lombok.Data;

@Data
public class RegisterRequestDto {
    private String username;

    private String password;

    private String fullname;

    private String role;
}
