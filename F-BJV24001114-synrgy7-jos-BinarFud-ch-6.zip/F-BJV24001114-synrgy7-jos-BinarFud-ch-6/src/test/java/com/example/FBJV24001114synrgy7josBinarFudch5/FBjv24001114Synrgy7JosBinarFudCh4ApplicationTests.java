package com.example.FBJV24001114synrgy7josBinarFudch5;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FBjv24001114Synrgy7JosBinarFudCh4ApplicationTests {

	@Test
	void contextLoads() {
	}

}
